from distutils.core import setup

setup(
    name='nester',
    version='1.0.0',
    py_modules=['nester'],
    author='sunpeng',
    author_email='sunpeng@muc.edu.cn',
    url='http://www.sunpeng.com',
    description='A simple printer of nested lists.'
)